import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  Button
} from "shards-react";

import PageTitle from "../../components/common/PageTitle";
// import { useHistory } from "react-router-dom"

//     const [getOperation, setGetOperation] = useState()

//     const history = useHistory()

//     const getRequest = () => {
//       fetch("http://localhost:4000/api/v1/operation")
//         .then(response => response.json())
//         .then(data => setGetOperation(data))
//         .then(data => console.log(data))
//     }

//     useEffect(() => {
//       getRequest()
//     }, [])

//     const deleteOperation = ID => {
//       fetch(`http://localhost:4000/api/v1/operation/${ID}`, { method: "DELETE" })
//         .then(() => alert("Successfully removed...!"))
//         .then(() => window.location.reload())
//     }

//     const updateOperation = ID => {
//       window.sessionStorage.setItem("OperationID", ID)
//       history.push("/updateOperation")
//     }

class ViewPetOwner extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // Fourth list of posts.
      PostsListFour: []
    };
  }

  componentDidMount() {
    fetch('http://localhost:4000/api/v1/petowners')
    .then((response) => response.json())
    .then(petowners => {
        this.setState({ PostsListFour: petowners });
    });
  }

  render() {
    const {
      PostsListFour
    } = this.state;

    const deletePetOwner = (ID) =>{
      fetch(`http://localhost:4000/api/v1/petowners/${ID}`, { method: 'DELETE' })
      .then(() => alert("Successfully removed...!"))
      .then(()=> window.location.reload());
  }

    return (
    <Container fluid className="main-content-container px-4">
      {/* Page Header */}
      <Row noGutters className="page-header py-4">
        <PageTitle
          sm="4"
          title="Pet Owner"
          subtitle=""
          className="text-sm-left"
        />
      </Row>

      {/* Default Light Table */}
      <Row>
      
        <Col>
          <Card small className="mb-4">
            <CardHeader className="border-bottom">
              <h6 className="m-0">Details</h6>
            </CardHeader>
            <CardBody className="p-0 pb-3">
              <table className="table mb-0">
              <thead className="bg-light" style={{color: "blue"}}>

                  <tr>
                    <th scope="col" className="border-0">
                      #
                    </th>
                    <th scope="col" className="border-0">
                      First Name
                    </th>
                    <th scope="col" className="border-0">
                      Last Name
                    </th>
                    <th scope="col" className="border-0">
                      Address
                    </th>
                    <th scope="col" className="border-0">
                      Phone Number
                    </th>
                    <th scope="col" className="border-0">
                      Email
                    </th>
                    <th scope="col" className="border-0">
                      Occupation
                    </th>
                    <th scope="col" className="border-0">
                      Telephone
                    </th>
                    <th scope="col" className="border-0">
                      Emergency Contact
                    </th>
                    <th scope="col" className="border-0">
                      Action
                    </th>
                  </tr>
                </thead>
                {PostsListFour.map((post, idx) => (
                <tbody key={idx}>
                  <tr>
                  <td>{idx + 1}</td>
                    <td>{post.OFirstName}</td>
                    <td>{post.OLastName}</td>
                    <td>{post.Address}</td>
                    <td>{post.PhoneNumber}</td>
                    <td>{post.EmailAddress}</td>
                    <td>{post.Occupation}</td>
                    <td>{post.TelephoneNo}</td>
                    <td>{post.EmergencyContact}</td>
                    {/* <td>{post.DFirstName}</td> */}
                    <td>
                    <Row form>
  <Col md="6" className="mb-3">
    <Button theme="danger" onClick={() => deletePetOwner(post._id)}>Delete</Button>
  </Col>
  <Col md="6" className="mb-3">
    <Button
      theme="primary"
      style={{ marginLeft: '12px' }} // Add margin to the left of the button
    >
      Edit
    </Button>
  </Col>
</Row>


                    </td>
                  </tr>
                
                </tbody>
                ))}
              </table>
            </CardBody>
          </Card>
        </Col>
        
      </Row>
    </Container>
  );
}
}

export default ViewPetOwner;
