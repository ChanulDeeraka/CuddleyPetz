import React from "react";
import { Container, Row, Col, Card, CardHeader, CardBody, Button } from "shards-react";

import PageTitle from "../../components/common/PageTitle";

class StoreOrders extends React.Component 
{

  constructor(props) {
    super(props);

    this.state = {
      // Fourth list of posts.
      PostsListOne: []
    };
  }
  
  componentDidMount() {

    fetch('http://localhost:4000/api/v1/orderproduct')
    .then((response) => response.json())
    .then(orderList => {
        this.setState({ PostsListOne: orderList });
        console.log(orderList);
    });

  }

  render()
  {    
    const { PostsListOne } = this.state;
    return (
      <Container fluid className="main-content-container px-4">
        {/* Page Header */}
        <Row noGutters className="page-header py-4">
          <PageTitle sm="4" title="Orders" subtitle="Store" className="text-sm-left" />
        </Row>

        {/* Default Light Table */}
        <Row>
          <Col>
            <Card small className="mb-4">
              <CardHeader className="border-bottom">
                <h6 className="m-0">Active Orders</h6>
              </CardHeader>
              <CardBody className="p-0 pb-3">
                <table className="table mb-0">
                  <thead className="bg-light">
                    <tr>
                      <th scope="col" className="border-0">
                        Product ID
                      </th>
                      <th scope="col" className="border-0">
                        Qty
                      </th>
                      <th scope="col" className="border-0">
                        Amount
                      </th>
                      <th scope="col" className="border-0">
                        Order ID
                      </th>
                      <th scope="col" className="border-0">
                        Pet Owner Name
                      </th>
                      <th scope="col" className="border-0">
                        Pet Owner ID
                      </th>
                      <th scope="col" className="border-0">
                        Email
                      </th>
                      <th scope="col" className="border-0">
                        Order Address
                      </th>
                      <th scope="col" className="border-0">
                        Date
                      </th>
                      <th scope="col" className="border-0">
                        Pick-Up Method
                      </th>
                      <th scope="col" className="border-0">
                        Payment Method
                      </th>
                      <th scope="col" className="border-0">
                        Order Status
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {
                    PostsListOne.map((post, idx) => (          
                      <tr key={post._id}>
                        <td>{post.ProductID}</td>
                        <td>{post.Qty}</td>
                        <td>$ {post.Amount}</td>
                        <td>{post.OrderID}</td>
                        <td>{post.petowner_details[0].OFirstName} {post.petowner_details[0].OLastName}</td>
                        <td>{post.petowner_details[0]._id}</td>
                        <td>{post.petowner_details[0].EmailAddress}</td>
                        <td>{post.petowner_details[0].Address}</td>
                        <td>{post.Date}</td>
                        <td>
                          <Row form>              
                              <Col md="12" className="mb-3">                                 
                                  {post.PickupMethod === "Pick-Up" ? <Button theme="warning">Pick-Up</Button> : <Button theme="primary">Delivery</Button>}
                              </Col>
                          </Row>          
                        </td>
                        <td>
                          <Row form>              
                              <Col md="12" className="mb-3">                                 
                                  {post.PaymentMethod === "Cash" ? <Button theme="success">Cash</Button> : <Button theme="info">Card</Button>}
                              </Col>
                          </Row>          
                        </td>
                        <td>
                          <Row form>              
                              <Col md="12" className="mb-3">   
                                  {post.OrderStatus === "Pending" ? <Button theme="dark">Preparing</Button> : <Button theme="danger">Delivered</Button>}
                              </Col>
                          </Row>          
                        </td>
                      </tr>
                    ))
                    }                 
                  </tbody>
                </table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    );
  };
};

export default StoreOrders;
