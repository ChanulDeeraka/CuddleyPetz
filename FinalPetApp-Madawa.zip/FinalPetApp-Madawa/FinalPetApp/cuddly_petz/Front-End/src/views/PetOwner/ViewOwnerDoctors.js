/* eslint jsx-a11y/anchor-is-valid: 0 */

import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  // Badge,
  Button
} from "shards-react";

import PageTitle from "../../components/common/PageTitle";

class ViewOwnerDoctors extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // Fourth list of posts.
      PostsListFour: []
    };
  }

  componentDidMount() {
    fetch('http://localhost:4000/api/v1/doctor')
    .then((response) => response.json())
    .then(doctorsList => {
        this.setState({ PostsListFour: doctorsList });
    });
  }

  render() {
    const {
      PostsListFour
    } = this.state;

    return (
      <Container fluid className="main-content-container px-4">
        {/* Page Header */}
        <Row noGutters className="page-header py-4">
          <PageTitle sm="4" title="Doctors" subtitle="Hospital" className="text-sm-left" />
        </Row>

        {/* Fourth Row of posts */}
        <Row>
          {PostsListFour.map((post, idx) => (
            <Col lg="3" md="6" sm="12" className="mb-4" key={idx}>
              <Card small className="card-post h-100">
                <div
                  className="card-post__image"
                  style={{ backgroundImage: `url("../../images/user-profile/08.jpg")` }}
                />
                <CardBody>
                  <h5 className="card-title">
                    <a className="text-fiord-blue" href="#">
                      {post.DFirstName} {post.DLastName}
                    </a>
                  </h5>
                  <h5 className="card-sub-title">
                    <a className="text-fiord-blue" href="#">
                      {post.DSpecialty}
                    </a>
                  </h5>
                  <p className="card-text">{post.DAbout}</p>
                </CardBody>
                <CardFooter className="text-muted border-top py-3">
                    <div className="row">
                      <div className="col-4">
                      </div>
                      <div className="col-4">
                        <div className="my-auto ml-auto">
                          <Button href="/make-appoinments-byUser" size="sm" theme="warning" className="mb-2">
                            Channel
                          </Button>
                        </div>
                      </div>
                      <div className="col-4">
                      </div>
                    </div>
                </CardFooter>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    );
  }
}

export default ViewOwnerDoctors;
