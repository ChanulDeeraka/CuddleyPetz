/* eslint jsx-a11y/anchor-is-valid: 0 */

import React from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardFooter,
  // Badge,
  Button
} from "shards-react";

import PageTitle from "../components/common/PageTitle";
import { NavLink as RouteNavLink } from "react-router-dom";
import { NavLink } from "shards-react";
class BlogPosts extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // Third list of posts.
      PostsListOne: [
        // {
        //   author: "John James",
        //   authorAvatar: require("../images/avatars/1.jpg"),
        //   title: "Had denoting properly jointure which well books beyond",
        //   body:
        //     "In said to of poor full be post face snug. Introduced imprudence see say unpleasing devonshire acceptance son. Exeter longer wisdom work...",
        //   date: "29 February 2019"
        // },
        // {
        //   author: "John James",
        //   authorAvatar: require("../images/avatars/2.jpg"),
        //   title: "Husbands ask repeated resolved but laughter debating",
        //   body:
        //     "It abode words began enjoy years no do ﻿no. Tried spoil as heart visit blush or. Boy possible blessing sensible set but margaret interest. Off tears...",
        //   date: "29 February 2019"
        // },
        // {
        //   author: "John James",
        //   authorAvatar: require("../images/avatars/3.jpg"),
        //   title:
        //     "Instantly gentleman contained belonging exquisite now direction",
        //   body:
        //     "West room at sent if year. Numerous indulged distance old law you. Total state as merit court green decay he. Steepest merit checking railway...",
        //   date: "29 February 2019"
        // }
      ],
      PostsListTwo:[]
    };
  }

  
  componentDidMount() {
    fetch('http://localhost:4000/api/v1/blog?BlogType=Blog')
    .then((response) => response.json())
    .then(blogList => {
        this.setState({ PostsListOne: blogList });
    });

    fetch('http://localhost:4000/api/v1/blog?BlogType=Article')
    .then((response) => response.json())
    .then(blogList2 => {
        this.setState({ PostsListTwo: blogList2 });
    });
  }

  render() {
    const {
      // PostsListOne,
      PostsListTwo,
      PostsListOne,
      // PostsListFour
    } = this.state;

    return (
      <Container fluid className="main-content-container px-4">
        {/* Page Header */}
        <Row noGutters className="page-header py-4">
          <Col lg="10">
            <PageTitle sm="4" title="Blog Posts" subtitle="Blog" className="text-sm-left" />
          </Col>
          <Col lg="2">
            <NavLink tag={RouteNavLink} to={"/add-new-blog"}>
              <Button size="lg" theme="primary" className="float-end">
                <i className="far fa-edit mr-1" /> New Blog
              </Button>
            </NavLink>
          </Col>
          </Row>

        {/* Third Row of Posts */}
        <Row>
          {PostsListOne.map((post, idx) => (
            <Col lg="12" key={idx}>
              <Card small className="card-post mb-4">
                <CardBody>
                  <h5 className="card-title">{post.Title}</h5>
                  <p className="card-text text-muted">{post.Description}</p>
                </CardBody>
                <CardFooter className="border-top d-flex">
                  <div className="card-post__author d-flex">
                    <a
                      href="#"
                      className="card-post__author-avatar card-post__author-avatar--small"
                      style={{ backgroundImage: `url('${require("../images/avatars/1.jpg")}')` }}
                    >
                      Written by James Khan
                    </a>
                    <div className="d-flex flex-column justify-content-center ml-3">
                      <span className="card-post__author-name">
                        {post.PostedBy}
                      </span>
                      <small className="text-muted">{post.PostedDate}</small>
                    </div>
                  </div>
                  <div className="my-auto ml-auto">
                    <NavLink tag={RouteNavLink} to={`/blog-comments?blogID=${post._id}`}>
                      <Button size="sm" theme="white" className="mb-2">
                        <i className="far fa-edit mr-1" /> Comments
                      </Button>
                    </NavLink>
                  </div>
                </CardFooter>
              </Card>
            </Col>
          ))}
        </Row>

        {/* Page Header */}
        <Row noGutters className="page-header py-4">
          <Col lg="10">
            <PageTitle sm="4" title="Article Posts" subtitle="Article" className="text-sm-left" />
          </Col>
          <Col lg="2">
            <NavLink tag={RouteNavLink} to={"/add-new-blog"}>
              <Button size="lg" theme="info" className="float-end">
                <i className="far fa-edit mr-1" /> New Article
              </Button>
            </NavLink>
          </Col>
          </Row>

        {/* Third Row of Posts */}
        <Row>
          {PostsListTwo.map((post, idx) => (
            <Col lg="12" key={idx}>
              <Card small className="card-post mb-4">
                <CardBody>
                  <h5 className="card-title">{post.Title}</h5>
                  <p className="card-text text-muted">{post.Description}</p>
                </CardBody>
                <CardFooter className="border-top d-flex">
                  <div className="card-post__author d-flex">
                    <a
                      href="#"
                      className="card-post__author-avatar card-post__author-avatar--small"
                      style={{ backgroundImage: `url('${require("../images/avatars/3.jpg")}')` }}
                    >
                      Written by James Khan
                    </a>
                    <div className="d-flex flex-column justify-content-center ml-3">
                      <span className="card-post__author-name">
                        {post.PostedBy}
                      </span>
                      <small className="text-muted">{post.PostedDate}</small>
                    </div>
                  </div>
                  <div className="my-auto ml-auto">
                    <NavLink tag={RouteNavLink} to={`/blog-comments?blogID=${post._id}`}>
                      <Button size="sm" theme="white" className="mb-2">
                        <i className="far fa-edit mr-1" /> Comments
                      </Button>
                    </NavLink>
                  </div>
                </CardFooter>
              </Card>
            </Col>
          ))}
        </Row>

      </Container>
    );
  }
}

export default BlogPosts;
