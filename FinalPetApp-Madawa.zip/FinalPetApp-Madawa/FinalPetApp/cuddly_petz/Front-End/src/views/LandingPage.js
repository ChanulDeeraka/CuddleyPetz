// import React from "react";
// import { Link } from "react-router-dom";
// // import { Button } from "shards-react";

// import "./styles.css";

// function LandingPage() {
//   return (
//     <main>
//       <div>
//         <span>Welcome To!</span>
//         <h1>CuddlyPetz</h1>
//         <hr />
//         <p>
//           Beauty and mystery are hidden under the sea. Explore with our
//           application to know about Aquatic Animals.
//         </p>
//         <Link to="/login">Next</Link>
//       </div>
//       <div className="landing-page-image">
//         <img
//           src="https://www.example.com/image.jpg"
//           alt="A beautiful"
//         />
//       </div>
//     </main>
//   );
// }

// export default LandingPage;
