// import React from "react";
// import { Redirect } from "react-router-dom";

import Login from "./views/Authentication/LoginPage";

export default [
  {
    path: "/login",
    component: Login
  }
];
