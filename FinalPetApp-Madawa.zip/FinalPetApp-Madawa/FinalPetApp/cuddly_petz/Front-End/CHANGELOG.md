# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0] - 2019-01-07

- Initial release.
