import { Router } from "express";
const router = Router();

import upload from "../utils/multer.js";
import {
  addPetOwner,
  getPetOwnerById,
  updatePetOwner,
  getAllPetOwner,
  deletePetOwner,
} from "../controller/petOwner.controller.js";

router.route("/").post(upload.single("avatar"), addPetOwner);
router.route("/").get(getAllPetOwner);
router.route("/:id").get(getPetOwnerById);
router.route("/:id").put(upload.single("avatar"), updatePetOwner);
router.route("/:id").delete(deletePetOwner);

export default router;
