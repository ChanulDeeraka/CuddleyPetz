import mongoose from "mongoose";

const petRecordSchema = new mongoose.Schema(
  {
    PetName: {
      type: String,
      require: true,
    },
    PetOwnerID: {
      type: String,
      require: true,
    },
    RecordType: {
      type: String,
      require: true,
    },
    Note: {
      type: String,
      require: true,
    },
    avatar: {
      Data: Buffer,
      contentType: String,
    },
    cloudinary_id: {
      type: String,
      require: true,
    },
  },
  {
    timestamps: false,
    versionKey: false,
  }
);

export default mongoose.model.Pet_Record ||
  mongoose.model("Pet_Record", petRecordSchema);
