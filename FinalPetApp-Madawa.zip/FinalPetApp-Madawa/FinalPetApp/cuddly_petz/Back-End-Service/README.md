# Hotel-Management-System
SLIIIT || 3rd Year 2nd Semester || Model Code - SE3080

# Devices

### VS Code settings

- Create .vscode directory and settings.json inside the directory

`mkdir .vscode && touch .vscode/settings.json`

- Add the following inside the settings.json

```json
{
  "editor.formatOnSave": true,
  "files.autoSave": "onFocusChange"
}
```

### Environment Variables

```
PORT=6000
MONGO_URL=mongodb+srv://Theebanraj:Lucifer2022@cluster0.jqhf1.mongodb.net/?retryWrites=true&w=majority
CLOUDINARY_CLOUD_NAME=cloudbucket
CLOUDINARY_API_KEY=583638378746911
CLOUDINARY_API_SECRET=ZnezkYnCUErerhatAXaH1OL3njA

```
